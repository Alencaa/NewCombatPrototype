﻿using CombatV2.Combat;
using CombatV2.Player;
using System.Collections;
using UnityEngine;

namespace CombatV2.FSM.States
{
    public class PlayerAttackState : CharacterState<PlayerController>
    {
        private readonly GestureData gesture;
        private float attackDuration = 0.6f; // tạm hardcode, sau sẽ lấy từ config
        private float timer;

        public PlayerAttackState(PlayerController owner, StateMachine<PlayerController> stateMachine,  GestureData gesture) : base(owner, stateMachine)
        {
            this.gesture = gesture;
        }

        public override void Enter()
        {
            base.Enter();
            string anim = $"Slash_{gesture.type.ToString().Replace("Slash", "")}";
            Owner.Animator.Play(anim);
            Debug.Log($"▶ FSM Attack → {anim}");
            Owner.TextDebug.text = $"Attack: {anim}";

            timer = 0f;
        }

        public override void Update()
        {
            base.Update();

            timer += Time.deltaTime;
            if (timer > attackDuration)
            {
                Debug.Log($"✅ Attack completed: {gesture.type}");
                stateMachine.ChangeState(new PlayerIdleState(Owner, stateMachine));
            }
        }

        public override void Exit()
        {
            base.Exit();
            Debug.Log($"➡ Exit AttackState → back to Idle");
        }
    }

}
