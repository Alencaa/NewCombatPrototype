﻿using CombatV2.FSM;
using CombatV2.FSM.States;
using System.Collections;
using TMPro;
using UnityEngine;

/// <summary>
/// Xử lý hành vi phòng thủ và phản ứng sát thương của người chơi.
/// </summary>
public class PlayerController : MonoBehaviour
{


    [Header("Combat Settings")]
    public int maxHP = 100;
    public float parryWindow = 0.3f;
    public bool isInvincible = false;

    private int currentHP;
    private bool isParryActive = false;
    public bool IsHoldingBlock { get; set; }

    [Header("Block Arrow")]
    [SerializeField] private GameObject blockArrowPrefab;
    private GameObject blockArrowInstance;
    public Vector2 CurrentBlockDirection { get;  set; }

    public Animator Animator => animator; // Gán Animator từ Inspector
    public TextMeshPro TextDebug => textDebug; // Gán Animator từ Inspector

    [SerializeField] private Animator animator;
    [SerializeField] private TextMeshPro textDebug;
    //STATE MACHINE
    private StateMachine<PlayerController> stateMachine;
    public StateMachine<PlayerController> StateMachine => stateMachine;
    
    private void Awake()
    {
        stateMachine = new StateMachine<PlayerController>(this);
        stateMachine.ChangeState(new PlayerIdleState(this, stateMachine));
    }
    private void Start()
    {
        currentHP = maxHP;
    }

    private void Update()
    {
        stateMachine.Update();
    }

   
    public bool IsBlocking() => IsHoldingBlock;
    public bool IsParrying() => isParryActive;

    /// <summary>
    /// Kích hoạt parry window trong khoảng thời gian ngắn
    /// </summary>
    public void StartParryWindow(float duration)
    {
        StopCoroutine(nameof(ParryWindowCoroutine));
        StartCoroutine(ParryWindowCoroutine(duration));
    }

    private IEnumerator ParryWindowCoroutine(float duration)
    {
        isParryActive = true;
        Debug.Log("Parry Window ACTIVE");
        yield return new WaitForSeconds(duration);
        isParryActive = false;
        Debug.Log("Parry Window END");
    }

    public void UpdateBlockDirection(Vector2 inputDir)
    {
        if (inputDir != Vector2.zero)
            CurrentBlockDirection = inputDir.normalized;
    }

    /// <summary>
    /// Gọi từ enemy → xử lý mất máu
    /// </summary>
    public void TakeDamage(int amount)
    {
        if (isInvincible) return;

        currentHP -= amount;
        Debug.Log($"Player took {amount} damage. Current HP: {currentHP}");

        if (currentHP <= 0)
        {
            Die();
        }
        else
        {
            PlayHurtFeedback();
        }
    }

    private void Die()
    {
        Debug.Log("Player Died");
        // TODO: Trigger death animation & restart
    }

    private void PlayHurtFeedback()
    {
        // TODO: Trigger hurt animation, flash, etc.
        Debug.Log("Player Hurt Feedback Triggered");
    }

    public void RequestAttackState(GestureData gesture)
    {
        stateMachine.ChangeState(new PlayerAttackState(this, stateMachine, gesture));
    }

    public string GetDirectionName(Vector2 dir)
    {
        float angle = Vector2.SignedAngle(Vector2.right, dir);

        if (angle >= -22.5f && angle <= 22.5f) return "Right";
        if (angle > 22.5f && angle <= 67.5f) return "UpRight";
        if (angle > 67.5f && angle <= 112.5f) return "Up";
        if (angle > 112.5f && angle <= 157.5f) return "UpLeft";
        if (angle > 157.5f || angle <= -157.5f) return "Left";
        if (angle < -112.5f && angle >= -157.5f) return "DownLeft";
        if (angle < -67.5f && angle >= -112.5f) return "Down";
        if (angle < -22.5f && angle >= -67.5f) return "DownRight";

        return "None";
    }

    public void ShowBlockArrow(Vector2 direction)
    {
        if (blockArrowInstance == null)
        {
            blockArrowInstance = Instantiate(blockArrowPrefab, transform);
            blockArrowInstance.transform.localPosition = new Vector2 (0, -0.2f);
        }

        blockArrowInstance.SetActive(true);
        RotateArrow(direction);
    }

    public void RotateArrow(Vector2 direction)
    {
        if (blockArrowInstance == null) return;
        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        blockArrowInstance.transform.rotation = Quaternion.Euler(0, 0, angle);
    }

    public void HideBlockArrow()
    {
        if (blockArrowInstance != null)
            blockArrowInstance.SetActive(false);
    }
}
