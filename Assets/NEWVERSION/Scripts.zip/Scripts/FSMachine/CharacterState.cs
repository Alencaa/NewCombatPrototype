using System.Collections;
using UnityEngine;

namespace CombatV2.FSM
{
    public abstract class CharacterState<T> where T : MonoBehaviour
    {
        protected T Owner { get; }
        protected StateMachine<T> stateMachine;

        public CharacterState(T owner, StateMachine<T> stateMachine)
        {
            Owner = owner;
            this.stateMachine = stateMachine;
        }

        public virtual void Enter() { }
        public virtual void Exit() { }
        public virtual void Update() { }
        public virtual void FixedUpdate() { }

        protected void ChangeStateWithDelay(CharacterState<T> newState, float delay)
        {
            Owner.StartCoroutine(ChangeStateAfterDelay(newState, delay));
        }

        private IEnumerator ChangeStateAfterDelay(CharacterState<T> newState, float delay)
        {
            yield return new WaitForSeconds(delay);
            stateMachine.ChangeState(newState);
        }
    }
}
