﻿using UnityEngine;
using System.Collections.Generic;
namespace CombatV2.FSM.States
{
    public class PlayerComboState : CharacterState<PlayerController>
    {
        private readonly string comboName;
        private readonly List<GestureData> comboSteps;

        public PlayerComboState(PlayerController owner, StateMachine<PlayerController> stateMachine, string comboName, List<GestureData> steps)
            : base(owner, stateMachine)
        {
            this.comboName = comboName;
            this.comboSteps = steps;
        }

        public override void Enter()
        {
            base.Enter();

            string animName = $"Combo_{comboName}";
            Owner.Animator.Play(animName);
            Debug.Log($"💥 FSM Combo → Play {animName} ({comboSteps.Count} steps)");
        }

        public override void Update()
        {
            base.Update();

            var animState = Owner.Animator.GetCurrentAnimatorStateInfo(0);
            if (animState.IsName($"Combo_{comboName}") && animState.normalizedTime >= 1f)
            {
                Debug.Log($"✅ Combo {comboName} completed");
                stateMachine.ChangeState(new PlayerIdleState(Owner, stateMachine));
            }
        }

        public override void Exit()
        {
            base.Exit();
            Debug.Log($"➡ Exit ComboState → back to Idle");
        }
    }
}
