﻿using UnityEngine;

public class PlayerCombatMock : MonoBehaviour
{
    public bool DidPerfectParryThisFrame = false;
    public bool IsBlocking = false;
    public bool IsGuardBroken = false;

    // ✳️ Gán giá trị này tạm từ Inspector hoặc Animation Event để test
}
